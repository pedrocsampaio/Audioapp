import 'package:flutter/material.dart';
import 'Scenes/Detail/overview.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false, // Remove o banner de debug
      title: 'Product Details',
      theme: ThemeData(
        scaffoldBackgroundColor: Colors.white,
      ),
      home: const ProductDetailScreen(), // Tela inicial
    );
  }
}
