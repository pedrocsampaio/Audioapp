import 'package:flutter/material.dart';
import '../../DesignSystem/Components/Carousel/category.dart';
import '../../DesignSystem/Components/Review/review.dart';
import '../../DesignSystem/Components/Review/review_view_model.dart';

class ProductDetailScreen extends StatelessWidget {
  const ProductDetailScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Product Details'),
        backgroundColor: Colors.white,
        foregroundColor: Colors.black,
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Nome do Produto
            const Text(
              'TMA-2 Comfort Wireless',
              style: TextStyle(
                fontSize: 28,
                fontWeight: FontWeight.w700,
                fontFamily: 'DM Sans',
              ),
            ),
            const SizedBox(height: 8), // Espaço entre o nome e o preço

            // Preço do Produto
            const Text(
              'USD 270',
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w700,
                fontFamily: 'DM Sans',
              ),
            ),
            const SizedBox(height: 16), // Espaço entre o preço e a categoria

            // Design System da Categoria
            Row(
              children: [
                CategoryItem(
                  title: 'Wireless',
                  isSelected: true,
                  onTap: () {}, // Implemente a ação
                ),
                const SizedBox(width: 8),
                CategoryItem(
                  title: 'Over-ear',
                  isSelected: false,
                  onTap: () {}, // Implemente a ação
                ),
              ],
            ),
            const SizedBox(height: 24), // Espaço entre a categoria e a imagem

            // Imagem do Produto
            Center(
              child: Container(
                width: 246,
                height: 246,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10),
                  image: const DecorationImage(
                    image: AssetImage(
                        '../../assets/product.png'), // Substitua pelo caminho correto
                    fit: BoxFit.cover,
                  ),
                ),
              ),
            ),
            const SizedBox(
                height: 24), // Espaço entre a imagem e o título Review

            // Título de Review
            const Text(
              'Reviews',
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w400,
                fontFamily: 'DM Sans',
              ),
            ),
            const SizedBox(
                height: 29), // Espaço entre o título e o componente de review

            // Componente de Review
            ReviewComponent(
              viewModel: ReviewViewModel(), // Use a view model já implementada
            ),
            const SizedBox(height: 40), // Espaço entre o review e o botão

            // Botão Add to Cart
            SizedBox(
              width: double.infinity,
              height: 50,
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF0ACF83),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                ),
                onPressed: () {
                  // Ação do botão
                },
                child: const Text(
                  'Add to Cart',
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                    fontFamily: 'DM Sans',
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
