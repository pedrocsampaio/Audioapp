class ReviewViewModel {
  final String userName;
  final String userImageUrl;
  final int rating; // 0 a 5 estrelas
  final String comment;

  // Valores já definidos
  ReviewViewModel()
      : userName = 'Pedro Sampaio',
        userImageUrl = '../../assets/images/perfil.png',
        rating = 5,
        comment = 'Ótimo produto! Recomendo para todos.';
}
